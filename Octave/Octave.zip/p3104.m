%Priklad 3.1-04
clc;
pkg load symbolic;
%*******************************************************************************
%!!! Z dovodu konvencie riesenia dif. rovnic symbolicky,musime zamenit dx za dy
%*******************************************************************************
syms y y(t) g  t   f  dydt dydt2 v0  tt s sx vv0

dydt=diff(y,t)
dydt2=diff(dydt,t)==-f*g

%Dif. rovnica
%disp('Riesenie bez podmienok')
%Riesenie dif.rovnice
soldy0=dsolve(dydt2) % -draha
soldy1=diff(soldy0,t) %prva derivacia riesenia - rychlost

%disp('Riesenie s podmienkami y(0)=0, dey1(0)=vy(0) v case t0=0')
%Okrajove, zaciatocne podmienky
cond1=y(0)==0
cond2=dydt(0)==v0
cond=[cond1 cond2];
%Riesenie dif.rovnice
sldy0=(dsolve(dydt2,cond)) % -draha
sldy1=diff(sldy0,t) %prva derivacia riesenia - rychlost
tt=solve(sldy1,t)% vypocet casu

sx=subs(sldy0,t,tt)==s % Vypocet drahy

vv0=solve(sx,v0)% vypocet zaciaticnej rychlosti v0
disp('Zaporna rychlost je vylucena, tak ze plati koren v02=');
vv0(2)
%Koniec


