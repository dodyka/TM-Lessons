%Príklad 1.9.4-02
% Vstupne hodnoty
m=95
f21=0.3
f3=0.2
G=m*9.81
a21=30

a3=(3/4)*pi

Fk1=G*(e^(f3*a3))*((cosd(a21)*f21+sind(a21))/(cosd(a21)-sind(a21)))
disp("Podmienka pohybu Fpoh>Fk1")
