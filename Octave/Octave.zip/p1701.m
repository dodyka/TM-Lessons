%Priklad 1.7-01
clc;clearvars;
pkg load matgeom;
%Vstupne parametre
a=29.5
b=57
e=8
d=12
c=8.5
r=50
xr=45.5
yr=39.5
F3=450
E1=[45,0]
E2=[15,49]
vx=abs(xr-a)
vy=abs(yr+e)
v=[vx,vy]
eps=rad2deg(vectorAngle(v))
rr=sqrt(vx^2+vy^2) % polomer r, pre kontrolu

%Matice
A1=[c,0,0,cosd(eps)*d,0,0,0]
A2=[1,1,0,cosd(eps),0,0,0]
A3=[0,0,1,-1,0,0,0]
A4=[0,0,-sind(eps),0,0,0,0]
A5=[0,0,sind(eps),0,1,1,0]
A6=[0,0,-sind(eps)*a,-cosd(eps)*e,0,-b,0]
A7=[0,0,-cosd(eps),0,0,0,1]
A=[A1;A2;A3;A4;A5;A6;A7]
B=[0;0;0;-F3;0;0;0]
AI=inv(A)
C=AI*B
%Vysledky
disp("Uhol epsilon:");
disp(eps)
R13C=C(1)
R13D=C(2)
R32E=C(3)
R23E=C(4)
R12A=C(5)
R12B=C(6)
F2=C(7)
