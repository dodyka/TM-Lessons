## Algoritmus 1.1.3-01

pkg load matgeom;clearvars; clc;
figure(11301); clf;
axis([-10 10 -10 10 -10 10]);
h = drawSphere([0 0 0 8], 'nPhi', 360, 'nTheta', 360);
set(h, 'facecolor', 'g');
l = light; view(3);hold on; lighting gouraud ; hold on;
grid on;hold on;
figure(11301);
set(gca, "linewidth", 2, "fontsize", 14)
xlabel ("x");ylabel ("y");zlabel ("z");
title ("Guľa");  hold on;
p1=[0 -8 1]; [theta,phi,r]=cart2sph(p1); ctsp=[theta,phi,r];
figure(11301);
px=[0 0]; py=[-8 -8]; pz=[-10 10];
drawPolyline3d(px,py,pz,'k','linewidth',3,'linestyle',':'); hold on;
p1=[0 -8 0]; pcyl=cart2cyl(p1);
drawPoint3d(p1,'k','linewidth',20); hold on;
p2=[0,-9,0];drawLabels3d(p2,'Bod p1','fontsize', 20);hold on;
p3=[0,-9,-8]; drawLabels3d(p3,'t','fontsize', 20);hold on;
axis equal; hold off;
disp("Ortogonalne suradnice bodu X,Y,Z :"); disp(p1);
disp("Gulove suradnice bodu theta,phi,r :");disp(ctsp);
disp("Theta v stupnoch:"); disp(rad2deg(theta));
disp("Phi v stupnoch:"); disp(rad2deg(phi));

