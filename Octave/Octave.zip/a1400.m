%Algoritmus 1.4-01
clc;clearvars
pkg load symbolic
syms i j k Fx Fy Fz x y z M
M=[i,j,k;x,y,z;Fx,Fy,Fz]
md=pretty(det(M))


