%Priklad 2.1-04
clc;clearvars;
pkg load symbolic;
syms y t y(t) k1 k2 v0 t2 sv tv
% Zostavenie dif. rovnice
de1=diff(y,t) % prva derivacia
de2=diff(y,t,2) % druha derivacia
de=de2-k1+k2*t==0 % diferencialna rovnica (1)
%Okrajove podmienky
cond1=y(0)==0
cond2=de1(0)==v0 %
cond=[cond1 cond2];
%Riesenie dif.rovnice
disp("Draha")
sol=dsolve(de,cond) % riesenie dif. rovnice (1)
dsol=diff(sol,t) %prva derivacia vseobecneho riesenie
eqr=solve(dsol==0,t)
disp("Cas do zastavenia");
t2=eqr(2)
tv=function_handle(t2);% funkcia casu
sv=function_handle(sol);% funkcia drahy
%Vstupne parametre
kk1=9
kk2=7
vv0=10
%Vysledky
cas=tv(kk1,kk2,vv0)
draha=sv(kk1,kk2,cas,vv0)
