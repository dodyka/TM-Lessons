## Algoritmus 1.1.2-01
pkg load matgeom; clc; clearvars;
f=figure(11201);
axis([-40 40 -40 40 -40 40]);axis equal;
cyl = [0 0 -35 0 0 35 30];%[X1 Y1 Z1 X2 Y2 Z2 r]
[v, f] = cylinderMesh(cyl);
drawMesh(v, f, 'FaceColor', 'none');
hold on; view(3); axis equal;hold on;
grid on;hold on;
set(gca, "linewidth", 2, "fontsize", 14)
xlabel ("x");ylabel ("y");zlabel ("z");
title ("Valec"); p1=[0 -30 35]; pcyl=cart2cyl(p1);
drawPoint3d(p1,'k','linewidth',5); hold on;
drawLine3d([0 0 -40   0 0 40], 'linewidth',2); % len v smeroch osi vykresluje
drawLine3d([-40 0 0   40 0 0],'linewidth',2);
drawLine3d([0 -40 0   0 40 0],'linewidth',2);
disp("Ortogonalne suradnice bodu X,Y,Z :"); disp(p1);
disp("Valcove suradnice bodu theta,r,Z :");disp(pcyl);
disp("Theta v stupnoch:");
disp(rad2deg(pcyl(1)));
