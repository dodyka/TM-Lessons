%Priklad 1.5.1-18
clc;clearvars;
a=1.7
b=2.3
bt=55
Fc=855

A=[1,0,-cosd(bt);0,1,sind(bt);0,0,-sind(bt)*a]

AI=inv(A)

B=[0;Fc;-Fc*(a+b)]

C=AI*B

