%algoritmus a1.4.04
clc;clearvars;
pkg load quaternion;
r=quaternion(0,5,3,5)
F1=quaternion(0,8,-5,-5)
F2=quaternion(0,4,10,-10)
F3=quaternion(0,3,20,-15)
F12=plus(F1,F2)
F123=plus(F12,F3)
M0=times(r,F123)
vM0=[get(M0,'x'),get(M0,'y'),get(M0,'z')]
absM0=norm(vM0)
