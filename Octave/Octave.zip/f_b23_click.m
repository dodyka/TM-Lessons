## Copyright (C) 2024 dodko283
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} b23_click (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: dodko283 <dodko283@KKS-190>
## Created: 2024-06-13

function f_b23_click (~, ~,hlb)
%disp("Veselo klikam"); %for debug purpose
itemindex=get(hlb,'value');
global listitems;
%disp(listitems(itemindex,1));%for debug purpose
rns=listitems{itemindex};
source(rns);

endfunction
