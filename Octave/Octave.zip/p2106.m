%Priklad 2.1-06
clc;clearvars;
syms y(t) t g th h
de1=diff(y,t)
de2=diff(y,t,2)
de=de2-g==0
%Okrajove, zaciatocne podmienky
cond1=y(0)==0
cond2=de1(0)==0%
cond=[cond1 cond2];
%Riesenie dif.rovnice
disp("Riesenie dif. rovnice")
disp("Draha")
sol=dsolve(de,cond) % riesenie dif. rovnice (1)
disp("Rychlost")
dsol=diff(sol,t)
disp("Cas")
assume('h','positive');
assume('g','positive');
assume('t','positive');
t=solve(h==sol,t)
