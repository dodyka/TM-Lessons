## Copyright (C) 2024 dcrdl
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} f_rotycs4 (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: dcrdl <dcrdl@LENOVO-UKST190>
## Created: 2024-12-21

function retval = f_rotycs4 (beta)
tmp=eye(4);
tmp(1,1)=cosd(beta);
tmp(3,1)=sind(beta);
tmp(1,3)=-sind(beta);
tmp(3,3)=cosd(beta);
retval=tmp;
endfunction
