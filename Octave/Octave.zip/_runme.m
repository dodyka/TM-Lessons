flpth="D:\\Dodo\\Dokumenty\\Pracovne\\Education\\_Technicka mechanika\\Skripta a ucebnice\\Mechanika Navody-skripta 2024\\Octave\\_smanager.m";
source(flpth);
