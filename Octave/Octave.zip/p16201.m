%Priklad 1.6.2-01
clc;clearvars;
pkg load matgeom;
%Vstupne parametre
a=29.5
b=57
e=8
d=12
c=8.5
r=50
xr=45.5
yr=39.5
F3=450
E1=[45,0]
E2=[15,49]
vx=abs(xr-a)
vy=abs(yr+e)
v=[vx,vy]
tau=rad2deg(vectorAngle(v))
rr=sqrt(vx^2+vy^2) % polomer r, pre kontrolu
