%Priklad 2.1-03
clc;clearvars;
pkg load symbolic;

syms y t v y(t) g v0 h  tt h1 t1

% Zostavenie dif. rovnice
de1=diff(y,t) % prva derivacia
de2=diff(y,t,2) % druha derivacia
de=de2+g==0 % diferencialna rovnica (1)
%Okrajove podmienky
cond1=y(0)==0
cond2=de1(0)==v0-v % mozeme dat aj len v0, bez v
cond=[cond1 cond2];
%Riesenie dif.rovnice
sol=dsolve(de,cond) % riesenie dif. rovnice (1)
dsol=diff(sol,t) %prva derivacia vseobecneho riesenia
tt=solve(dsol,t)% vypocet casu
h1=subs(sol, t, tt)%vypocet vysky
%Vypocet s cislami
vv1=0 % ked h1(/=)0 sme vo vyske
vv0=15
vg=9.81
vhf=function_handle(h1);
vh1=vhf(vg,vv1,vv0) %Vypocet vysky h1
vtf=function_handle(tt);
vt1=vtf(vg,vv1,vv0) % vypocet casu t1

