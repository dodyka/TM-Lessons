%Priklad 1.5.2-01
L=1.7
q=1685
Q=q*L

A=eye(3)
B=[0;Q;-Q*L/2];
AI=inv(A)
C=AI*B
