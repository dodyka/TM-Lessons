%Priklad 2.3.3-02
%Roboticke rameno
%Rotujuce matice
%Clen L01 Suradnice zaciatok [Rx0,Ry0,Rz0], koniec [Rx1,Ry1,Rz1]
%Clen L12 Suradnice zaciatok [Rx1,Ry1,Rz1], koniec [Rx2,Ry2,Rz2], Otaca sa okolo osi clena L01 o uhol gamma
%Clen L23 Suradnice zaciatok [Rx2,Ry2,Rz2], koniec [Rx3,Ry3,Rz3], Otaca sa okolo osi clena L02 o uhol alpha
%--------------------------------------------------
%  SCHEMA ROBOTICKEHO RAMENA
%--------------------------------------------------
%                       C o Rx2,y2,z2
%                        /|
%                       / |L23
%                  L12 /  |
%                     / D o Rx3,y3,z3
%                    /
%                 B oRx1,y1,z1
%                   |
%                   |
%       |z          |
%       |           |L01
% x_____|0          |
%      /          A o Rx0,y0,z0
%     /            / \
%    y            -----
%                ////// zem, vsetky vazby su rotacne
%----------------------------------------------------
%Riesime len jednoduche pootocenie
%----------------------------------------------------
clc;
format short;
%Suradnice bodov
Rx0=0;Ry0=0;Rz0=0;
Rx1=0;Ry1=0;Rz1=0.4;
Rx2=0;Ry2=-0.3;Rz2=0.4;
Rx3=0;Ry3=-0.3;Rz3=0.2;
%Uhly pootocenia ramien
alpha=0;
beta=10;
gamma=10;
%Body
R2=[Rx2;Ry2;Rz2;1]
R3=[Rx3;Ry3;Rz3;1]
%Transformacne matice
disp('Transformacne matice postupne')
Ms1=[1,0,0,0;0,1,0,0;0,0,1,0.4;0,0,0,1]
%T21=f_rotz4(gamma) %Rotacia okolo osi Z
T21=k_rotz4(gamma) %Rotacia okolo osi Z
R3_1=T21*R3 %Suradnice pootoceneho bodu R3_1
%T32=f_roty4(beta) %Rotacoa okolo osi Y

T32=k_roty4(beta) %Rotacoa okolo osi Y

%R3_2=Ms*T32*R3_1 % Rotacia bodu R3_1

%Rotacia bodu R3 sucasne okolo Z )
%disp('Transformacne matice Sucasne')
%T31=T21*T32
%R3rot=T31*R3 % pootocenie bodu R3 o uhol gama a beta




