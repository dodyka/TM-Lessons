% Priklad 1.10-02
%Priestorove sustavy telies
clc; clearvars;
%Vstupne parametre
a=0.3
b=0.4
c=0.6
MR=125
Gr=7.5
GR=10
A1=[1,0,1,0,0]
A2=[0,1,0,1,0]
A3=[0,0,0,(b+c),0]
A4=[0,0,0,0,1]
A5=[0,0,(a+b),0,0]
B=[0;Gr+GR;GR*b-Gr*a;-MR;0]

A=[A1;A2;A3;A4;A5]
AI=inv(A)
MC=['ROx';'ROz';'RCx';'RCz';'Mr']
C=AI*B
