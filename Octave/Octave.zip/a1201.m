# Algoritmus a1.2-01
#Prevod medzi polarnou a ortogonalnou sustavou
clc; clearvars; pkg load nurbs; pkg load mapping; pkg load quaternion;
format long; %Nastaveny format long , vyssia presnost vypoctu
%Suradnice bodov
A0=[0 0]; %zaciatok vektora
A1=[5 12] %koniec vektora
rA=[A0 A1]; %vektor
disp("Dlzka:")
ra=vecmag(rA) % dlzka vektora, alebo mozno pouzit príkaz norm(A1)
[theta,r]=cart2pol(A1(1),A1(2)) % polarne suradnice , theta v rad
disp("Uhol orientacie:");
theta_deg=rad2deg(theta)
disp("Vypocet cez atan");
alpha=atand(A1(2)/A1(1))
disp("Spätny prevod");
[xx,yy]=pol2cart(theta, ra)
disp("Pouzitie Givens rotacie");
gvn=givens(A1(1),A1(2))
icos=(gvn(1,1));jsin=(gvn(1,2));
rx=ra*gvn(1,1)
ry=ra*gvn(1,2)
disp("Uhlova orientacia vektora z matice givens");
acosd(gvn(1,1))
asind(gvn(1,2))
f_drwVectors1(0,0,rx,ry,'b','r',1,'Vektor r','rx','ry');
disp("Smerový vektor z matice givens vo formáte quaternióna");
e0=quaternion(0,icos,jsin,0)





