%Algoritmus a1.5-01
clc;clearvars;pkg load matgeom;
F1=1250; F2=2400;F3=920;
a1=38;a3=40;
l1=0.25;l2=1;l3=1.15;l=2;

B1=F1*cosd(a1)-F3*cosd(a3);
B2=F1*sind(a1)+F2+F3*sind(a3);
B3=-F1*sind(a1)*l1-F2*l2-F3*sind(a3)*l3;

A=[1, 0,0;0,1,1;0,0,-l]
B=[B1; B2; B3]

C=inv(A)*B
vRA=[C(1) C(2)]
RA=vecmag(vRA)
aRA=rad2deg(vectorAngle(vRA))
