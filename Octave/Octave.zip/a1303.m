%algoritmus a1.3-03
clc;clearvars;
A=[-sqrt(3)/3,1;-1.226,1]
C=[14.226;0]
B=inv(A)*C
afr=atand(B(2)/B(1))

