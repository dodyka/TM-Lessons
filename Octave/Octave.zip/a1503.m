%Algoritmus a1.5-04
clc; clearvars;
L=3
F=1642
q=735
be=25
bb=90-be
Q=q*L


A=[1,0,-cosd(bb);0,1,sind(bb);0,0,sind(bb)]
B=[0;Q+F;(0.5*Q)+(7/4)*F]
AI=inv(A)
C=AI*B


