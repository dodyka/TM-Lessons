## Copyright (C) 2024 dodko283
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} tmtxsh (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: dodko283 <dodko283@KKS-190>
## Created: 2024-06-11
## create trans matrix  from 1 (shifted crd) to 0 (inertial)
## input matrix is [a;b;c;1], output matrix is 4x4
function retval = f_tmtxsh4 (shft)

nc=columns(shft);
if nc==1
   nr=rows(shft);
    if nr==4
     e0=eye(4);
     e0(1:4,4)=shft;
     retval=e0;
    else
      disp("Chyba: pocet riadkov matice musi byt 4");
      retval=0;
    endif
else
  disp("Chyba: pocet stlpcov matice musi byt 1");
      retval=0;
endif

endfunction
