## Copyright (C) 2024 dodko283
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} drawrotCrd3D (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: dodko283 <dodko283@KKS-190>
## Created: 2024-06-12

function retval=f_drawrotCrd3D (origin, rpm, angle, figure)

lsc=2;

figure=figure
%extract crd points from rpm - rotated points matrix
xp10=rpm(1:4,1); xm10=rpm(1:4,2);
yp10=rpm(1:4,3); ym10=rpm(1:4,4);
zp10=rpm(1:4,5); zm10=rpm(1:4,6);

%Vytvorenie trnasformacnej matice na rotaciu.
tm=rotxyzp4(angle,angle,angle) % rovnaky uhol lebo rotuje sur sustava, musi byt transponovana
%Rotovanie bodov sur sust.o1 voci o0, dostavame sustavu o2

xp2=tm*xp10; xm2=tm*xm10;
yp2=tm*yp10; ym2=tm*ym10;
zp2=tm*zp10; zm2=tm*zm10;

o10=origin; % suradnice posunutej sustavy, ta co ma rotovat

o13=transfp43(o10); % zaciatok posunutej sur sustavy

figure;
% o13 zaciatok posunutej sur sust.o1 voci o0 ale trojriadkova matice pre funkciu drawPoint3d
drawPoint3d(o13,'r','linewidth',4); hold on; % novy zaciatok posunutej sur.sust.
figure;
% nova suradnicova os- os X1
px1=[xp2(1),xm2(1)]; py1=[xp2(2),xm2(2)]; pz1=[xp2(3), xm2(3)];
drawPolyline3d(px1,py1,pz1,'k','linewidth',2,'linestyle','-');hold on;
figure;
%drawLabels3d(xp10(1)-lsc, xp10(2)-lsc, xp10(3)-lsc,'x2','fontsize', 20);hold on;
drawLabels3d(xm10(1)-lsc, xm10(2)-lsc, xm10(3)-lsc,'x2','fontsize', 20);hold on;

% nova suradnicova os- os Y1
figure;
px2=[yp2(1),ym2(1)]; py2=[yp2(2),ym2(2)]; pz2=[yp2(3), ym2(3)];
drawPolyline3d(px2,py2,pz2,'k','linewidth',2,'linestyle','-');hold on
figure;
drawLabels3d(yp2(1)-lsc, yp2(2)-lsc, yp2(3)-lsc,'y2','fontsize', 20);hold on;

% nova suradnicova os- os Z1
figure;
px3=[zp2(1),zm2(1)]; py3=[zp2(2),zm2(2)]; pz3=[zp2(3), zm2(3)];
drawPolyline3d(px3,py3,pz3,'k','linewidth',2,'linestyle','-');hold on
figure;
drawLabels3d(zp2(1)-lsc, zp2(2)-lsc, zp2(3)-lsc,'z2','fontsize', 20);hold on;

retval=[xp2,xm2,yp2,ym2,zp2,zm2];



endfunction
