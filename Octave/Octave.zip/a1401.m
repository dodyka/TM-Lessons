%Algoritmus 1.4-01
clc;clearvars
pkg load symbolic
disp("Definujem jednotkove vektory i j k");
i=[1,0,0]
j=[0,1,0]
k=[0,0,1]
disp("Definujem vektory r, F");
r=[4,5,3]
F=[1,10,-18]
disp("Vektorovy sucin M=r x F, so zlozkami Mx, My, Mz");
M=crossProduct3d(r,F)
disp("Uhly medzi vektormi M, r, F musia byt 90deg");
arM=rad2deg(vectorAngle3d(r,M))
aFM=rad2deg(vectorAngle3d(F,M))
disp("Hodnota momentu");
MA=norm(M)
disp("Uhly vektora M voci vektorom i j k, v stupnoch");
aiM=rad2deg(vectorAngle3d(i,M))
ajM=rad2deg(vectorAngle3d(j,M))
akM=rad2deg(vectorAngle3d(k,M))
