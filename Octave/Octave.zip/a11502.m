##Algoritmus 1.1.5-02
%Posunutie a rotacia sur systavy
% Zakladna sur.sust
pkg load matgeom; clc; clearvars;
%Label shift const, posunutie oznacenia sur. osi.
lsc=2;

figure(11502);
%Rozsah sur.osi.
axd=100;
axis([-axd axd -axd axd -axd axd]);axis equal;grid on;
hold on; view(3); hold on;
set(gca, "linewidth", 2, "fontsize", 14)
xlabel ("x");ylabel ("y");zlabel ("z");
title ("Posunutie sur.sustavy");
figure(11502);
f=figure(11502);
%pevna sur.sustava
%rozsah inercialnej sur osi
axi=90;
drawPoint3d(0,0,0,'k','linewidth',5); hold on;
drawLine3d([-axi 0 0   axi 0 0],'linewidth',2);hold on; % os x
drawLabels3d(axi+lsc, 0, 0,'x0','fontsize', 20);hold on;
drawLine3d([0 -axi 0   0 axi 0],'linewidth',2);hold on;
drawLabels3d(0, axi+lsc, 0,'y0','fontsize', 20);hold on;
drawLine3d([0 0 -axi   0 0 axi], 'linewidth',2); hold on;% len v smeroch osi vykresluje
drawLabels3d(0, 0, axi+lsc,'z0','fontsize', 20);hold on;

%Vykreslenie posunutej sur sustavy
%Posunutie sur sust.
sft=35;
origin4=[0;0;0;1]; shift4=[sft;sft;sft;1];
axscale=[55];
pcrd10=f_drawCrd3D(origin4, shift4, axscale, f)

%angle=-21;
% Vykreslenie pootocenej sur sustavy
%rcs=drawrotCrd3D (shift4, pcrd10, angle, f);






