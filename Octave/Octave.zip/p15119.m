%Priklad 1.5.1-19
clc;clearvars;
alf=30
bt=90-alf
r=0.85
xt=(4/3)*(pi/r)
yt=xt
b=(3/4)*r
m=25
g=9.81
G=m*g

A=[cosd(bt), 0, sind(bt); sind(bt),1,-cosd(bt);0, -b,sind(bt)*r]
AI=inv(A)

B=[G*sind(alf); G*cosd(alf);G*sind(alf)*yt-G*cosd(alf)*xt]

C=AI*B

