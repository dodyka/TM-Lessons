%Priklad 2.3.3-01
%Klukovy mechanizmus
clc;
pkg load symbolic;

syms xc r l t omg

xc(t)=r*cos(omg*t)+sqrt(l^2-(r*sin(omg*t))^2)

vc(t)=simplify(diff(xc,t))
ac(t)=simplify(diff(vc,t))

%Riesenie s cislami
ll=1
rr=0.5
tt=10 % cas simulacie 10s
n=100;
ta=transpose(linspace(0,tt,n));
omega=pi % uhlova rychlost 2.5 rad/s

xct=function_handle(xc(t));
vct=function_handle(vc(t));
act=function_handle(ac(t));

xcpos=transpose(zeros(1,n));
vxc=transpose(zeros(1,n));
axc=transpose(zeros(1,n));
fit=transpose(zeros(1,n));

for i=1:n
 fit(i)=omega*ta(i);
 xcpos(i)=xct(ll,omega,rr,ta(i));
 vxc(i)=vct(ll,omega,rr,ta(i));
 axc(i)=act(ll,omega,rr,ta(i));
endfor

%Vykreslenie graf. priebehov xc, vxc,axc
f=figure('Name','Uhol,draha, rychlost a zrychlenie bodu C','NumberTitle','off');
hold on;
figure(f);
plot (ta,fit,"black", 'linestyle',':','linewidth',1);
hold on;
figure(f);
plot (ta,xcpos,"black", 'linestyle','-','linewidth',1);
figure(f);
xlabel ("t,s");
ylabel ("fi(t),xc(t),vxc(t),axc(t)");
hold on;
figure(f);
plot (ta,vxc,"black", 'linestyle','--','linewidth',1);
figure(f)
plot (ta,axc,"black", 'linestyle','-.','linewidth',1);
hold on;
figure(f);
set(gca, "linewidth", 1, "fontsize", 12,'fontweight','bold');
figure(f);
title("Uhol, draha, rychlost a zrychlenie bodu C")
grid on;
hold on;
figure(f);
legend('{\fontsize{24} fi(t) }', '{\fontsize{24} xc(t) }','{\fontsize{24} vxc(t) }','{\fontsize{24} axc(t) }');
%set(gcf,'position',[200,100,800,600]); %funguje
hold off;
