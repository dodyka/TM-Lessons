%Priklad 3.4.1-03
clc;
pkg load symbolic;

syms r m Ft Fn alf bt G Jo f

Fn=G*cos(bt)

A=[1,m*r;r,-Jo]
B=[G*sin(bt);0]
C=[Ft;alf]
C=simplify(inv(A)*B)
f=C(1)/Fn

%Zadanie s cilami
btt=0.1745 %rad = 10 deg
rr=0.35 % m
mm=1.5 %kg
JJo=(1/2)*mm*rr^2
GG=mm*9.81
Fnvyp=GG*cos(btt)

fFt=function_handle(C(1))
Ftvyp=fFt(GG,JJo,btt,mm,rr)
ff=Ftvyp/Fnvyp
fAlf=function_handle(C(2))

alfa=fAlf(GG,JJo,btt,mm,rr)
