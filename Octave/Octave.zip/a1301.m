#Algoritmus 1.3-01
pkg load nurbs; pkg load mapping; clc;
F1=150; F2=95;F3=150;F4=225;
alfa1=27; alfa2=107; alfa3=194; alfa4=313;
F=[F1,F2,F3,F4]; %Sila
A=[alfa1,alfa2,alfa3,alfa4]; %Uhol
fmsg=['Sily F1..F4 [N] = ',num2str(F)];
amsg=['Uhly sil alfa1..alfa4 [deg] = ',num2str(A)];
%Pocet clenov riadkovej matice=poctu clenov zatazujucich sil
dim=size(F);
ix=dim(2);
% ulahcit indexovanie
disp(amsg);
disp(fmsg);
%Matice pre zlozky sil
Fx=zeros(1,ix); Fy=zeros(1,ix);
%Vypocet zloziek sil
for c=1:ix
    Fx(c)=single(F(c)*cosd(A(c)));
    Fy(c)=single(F(c)*sind(A(c)));
    fnx=strcat('Zlozka F',num2str(c),'x= ',num2str(Fx(c)), ' N');
    fny=strcat('Zlozka F',num2str(c),'y= ',num2str(Fy(c)), ' N');
    disp(fnx);
    disp(fny);
end

 %Scitanie zloziek sil
Fxx=sum(Fx); Fyy=sum(Fy);
fxmsg=['Suma sil v smere osi X= ',num2str(Fxx)];
fymsg=['Suma sil v smere osi Y= ',num2str(Fyy)];
disp(fxmsg); disp(fymsg);
%Vypocet vysledneho vektora sily
Fr=norm([Fxx;Fyy]);
%openvar Fx;
frmsg=['Vyslednica sil = ',num2str(Fr)]; disp(frmsg);
%vypocet orientacie vyslednice
af=rad2deg(vecangle(Fyy,Fxx));
afmsg=['Orientacia vyslednice = ', num2str(af), ' deg']; disp(afmsg);
%Vykreslenie vyslednice
%drwVectors(0,0,Fr,af,'red','Fv',1,'Vysledna sila Fv');
f_drwVectors1(0,0,Fxx,Fyy,'b','Fv',1,'Vysledna sila Fv','Fx, N','Fy, N');
%clearvars fmsg amsg ans c fmsg
disp('- Koniec vypoctu -');
%Ak chcem zapisat vypocitane udaje do subora
%saveData(pwd,'css_01_data');
