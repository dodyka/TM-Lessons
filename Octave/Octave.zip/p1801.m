%Príklad 1.8-01, tazisko
a=32
b=28
c=11
d=11
e=16
f=24.7
g=26.42
k=23
fi=31.76
%Teleso1,23
xt1=21.66
yt1=b+e+4.33
xt2=a/2
yt2=b+e/2
xt3=xt2
yt2=b+e/2
yt3=b/2
vt=f*sind(fi)
%Plochy 1,2,3
S1=(a-d+k)*vt/2
S2=c*e
S3=a*b
S123=[S1,S2,S3]
S=sum(S123)
xt123=[xt1*S1,xt2*S2,xt3*S3]
xt=sum(xt123)/S
yt123=[yt1*S1,yt2*S2,yt3*S3]
yt=sum(yt123)/S
disp("");
disp("Vysledok-poloha taziska");
disp("xt=");
disp(xt);
disp("yt=");
disp(yt);

