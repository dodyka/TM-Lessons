%Priklad 3.3-03
%Dynamika auto+privesny vozik
clc;
pkg load symbolic;

syms RA RB Rx Ry RD G1 G2 F ax m1 m2

eq1=F-Rx-m1*ax
eq2=Ry+RA+RB-G1==0
eq3=Rx-m2*ax
eq4=RD-Ry-G2==0

slx=eq1+eq3==0
solax=solve(slx,"ax")

%sol=solve(eq3,"ax")
