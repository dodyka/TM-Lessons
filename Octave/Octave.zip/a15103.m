%Algoritmus 1.5.1-03
clc; clearvars;
F1=750
F2=1380
F3=3400
a12=44
gm=26
a=2.3
b=2.3
c=3.2
d=3.2

A=[-cosd(a12),cosd(a12),1;sind(a12),sind(a12),0;0,0,-(a+b)]
B=[-F1+F3*cosd(gm);F2+F3*sind(gm);F1*a-F2*c-(F3*sind(gm))*(c+d)]
AI=inv(A)
C=AI*B
