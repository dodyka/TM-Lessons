####################################################################################################
## c.2024 doc. Ing. Jozef Redl, PhD. UKST, TF, SPU v Nitre
## Toto je jednoduchý manažér skriptov.
## Cez tento manažér môžete spúšťať akýkoľvek skript, len musíte zadať cestu.
## Na spúšťanie skriptov však môžete kľudne používať aj samotný GNU Octave cez File Browser.
## Tento manžér zároveň slúži aj ako ukážka programovania aplikácií s rozhraním.
## Ak máte naištalované všetky balíčky na Vašom OS tak by skripty mali bežať aj pod Linuxom a MAC Os.
## Všetky algoritmi môžete ľubovoľne meniť, využívať, publikovať, pokiaľ uvediete pôvodný zdroj.
## Celý balík je publikovaný pod licenciou GPL v3, https://www.gnu.org/licenses/gpl-3.0.en.html
######################################################################################################
clearvars;
global listitems=cell(1,1);

f_initmsg;
f=figure(10000,'visible','off');
set (f,'Name','Manažér skriptov v.1.0','NumberTitle','off', 'Resize', 'off','menubar','none','visible','off');
movegui(f,'center');set(f,'Visible','on');
%hlb1=uicontrol(f,"style","listbox","callback",@f_lb1_itemClick,"position",[10 40 540 280],'selectionhighlight',"on");
hlb1=uicontrol(f,"style","listbox","position",[10 40 540 280],'selectionhighlight',"on");
htx1=uicontrol(f,"style","text","string","Zoznam algoritmov","position",[10 330 540 25]);
htx2=uicontrol(f,"style","edit","string","","position",[10 10 540 25]);
hb1 = uicontrol (f, "string", "Nastaviť adresár","callback",{@f_b1_click,htx2,hlb1},"position",[10 370 120 40]);
hb2 = uicontrol (f, "string", "Info", "callback",@f_b2_click,"position",[135 370 120 40]);
hb23 = uicontrol (f, "string", "Run", "callback",{@f_b23_click, hlb1},"position",[260 370 120 40]);
hb3 = uicontrol (f, "string", "Koniec", "callback",@f_b3_click,"position",[400 370 120 40]);

%% END SCRIPT







