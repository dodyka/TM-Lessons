%Priklad 1.6.1.1-01, Obr.1.6.1.1-01
clc;clearvars;
F1=1550
F3=2840
a=4
fi=40
M1=[cosd(fi),0,0,0,0,0,1,1,0,0]
M2=[sind(fi),0,0,0,0,0,0,0,1,0]
M3=[0,0,0,0,-cosd(fi),-1,0,0,0,0]
M4=[0,0,0,0,sind(fi),0,0,0,0,1]
M5=[-cosd(fi),0,cosd(fi),0,0,0,0,0,0,0]
M6=[-sind(fi),-1,-sind(fi),0,0,0,0,0,0,0]
M7=[0,0,cosd(fi),cosd(fi),-cosd(fi),0,0,0,0,0]
M8=[0,0,sind(fi),-sind(fi),-sind(fi),0,0,0,0,0]
M9=[0,0,0,cosd(fi),0,1,-1,0,0,0]
M10=[0,1,0,sind(fi),0,0,0,0,0,0]

A=[M1;M2;M3;M4;M5;M6;M7;M8;M9;M10]
AI=inv(A)
B=[0;0;0;0;0;F1;F3;0;0;0]
C=AI*B

S1=C(1)
S2=C(2)
S3=C(3)
S4=C(4)
S5=C(5)
S6=C(6)
S7=C(7)

RAX=C(8)
RAY=C(9)
RB=C(10)
aRA=atand(RAY/RAX)
RA=sqrt(RAX^2+RAY^2)
