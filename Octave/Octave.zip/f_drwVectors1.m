## Algoritmus 2.1-02
function  f_drwVectors1(x0,y0,x1,y1,color, vectorname, direction,ctitle,xlbl,ylbl)
%digits(4);
vct1=[x0 x1];
vct2=[y0 y1];
f=figure(2102);
set (f,'Name',ctitle,'NumberTitle','off');
set(gcf,'color','w');
set(gca,'FontSize',6);
hold on;
grid on;

plot(vct1,vct2,"Color",color, "LineStyle",'-', "LineWidth", 2);
axis equal;
%text(x1/2+3.5,y1/2+3.5,vectorname);
ht = text ((x1/2)+1.5, (y1/2)+1.5, vectorname, "fontsize", 20);
set (ht, "color", 'black');
%title("Algoritmus 2.1-02");

if direction==1
    text(x1,y1,"+","Color",color,"FontSize",20);
elseif direction==-1
    text(x0,y0,"+","Color",color,"FontSize",20);
elseif direction==0
 %ziadny znak smeru
end
 set(gca, "linewidth", 2, "fontsize", 20)
 xlabel(xlbl);
 ylabel(ylbl);
 %fctx=x1/4;
 %fcty=y1/4;
 %xlabel('Fx, N','FontSize',12,'FontWeight','normal','Color','black');
 %ylabel('Fy, N','FontSize',12,'FontWeight','normal','Color','black');
 %axis([-x1-fctx  x1+fctx -y1-fcty y1+fcty]);
 % axis equal;
endfunction

