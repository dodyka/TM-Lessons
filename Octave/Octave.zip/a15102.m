%Algoritmus a1.5.1-02
clc;
FD=1250
alf=38
ee=90-alf
a=1
b=1
c=1
l=a+b+c
%variant1
A=[cosd(ee),0,0;sind(ee),-1,1;0,a,-(b+c)]
B=[FD*cosd(ee);FD*sind(ee);-FD*sind(ee)*l]
AI=inv(A)
C=AI*B
%variant 2
A2=[cosd(ee),0,0;0,a,-(a+b);sind(ee)*l,-(b+c),c]
B2=[FD*cosd(ee);-FD*sind(ee)*l;0]
AI2=inv(A2)
C2=AI2*B2
