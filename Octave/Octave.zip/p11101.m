%Priklad 1.11-01
pkg load symbolic;
clc; clearvars;
syms G a c l0 l8 x A(x)

A(x)=G*sind(a)+c*(l0-x)
disp("Integral A(x)=");
IA=simplify(int(A,l8,l0))
disp("Vstupne hodnoty+vypocet");
GG=100
alfa=30
cc=5950
ll0=99E-3
ll8=27.4E-3
Af=function_handle(IA);
disp("Praca sily F=Av [N.m]");
Av=Af(GG,alfa,cc,ll0,ll8)

