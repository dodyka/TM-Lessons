%Priklad 1.9-01
clc;clearvars;
%Zadane hodnoty
a=0.1
f23=0.1
f3=0.2
Fk1=2000
r=0.04
R=0.06
bt=pi
hr=(R-r)/2
Fk0=Fk1/((e^f3*bt))
A1=[1,1,f23,0,0,0]
A2=[-a,-2*a,0,0,0,0]
A3=[0,0,1,0,0,1]
A4=[0,0,-f23,1,0,0]
A5=[0,0,-1,0,1,0]
A6=[0,0,0,R/2,0,0]
A=[A1;A2;A3;A4;A5;A6]
B=[0;0;0;-Fk1-Fk0;0;-Fk1*(2*r+hr)+Fk0*hr]
AI=inv(A)
C=AI*B

MC=['R12A';'R12B';'F32nC';'R13xD';'R13yD';'F'];
disp('Vysledky:')
disp(MC);
disp(C);
F32tC=f23*C(3)

