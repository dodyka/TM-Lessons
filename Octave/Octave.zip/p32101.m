%Priklad 3.2.1-01 Teleso-pruzina
clc;
pkg load symbolic;
syms x(t) v(t) a(t) t om de(t) de1(t) de2(t) C1 C2 y eqn i o

%Dif rovnica
% x''+om^2*x=0
de1(t)=diff(x(t)) %prva derivacia
de2(t)=diff(de1(t),t) %druha derivacia
de(t)=de2(t)+om^2*x(t) % dif. rovnica (1)

%sol=dsolve(de,cond) % riesenie dif. rovnice (1)
sol=dsolve(de) % riesenie dif. rovnice (1) be zokr.podm

%Charakteristicka rovnica
eqn=y^2+om^2==0
%Vypocet korenov rovnice
qesol=solve(eqn)
%Korene char. rovnice
r1=qesol(1)
r2=qesol(2)

