
## Created: 2024-06-10
##
##  0rigin4- zaciatok ss povodnej, shift4 -matica posunutia, o10 novy zaciatok posunutej ss
##         | ox |          | u |
## origin4=| oy |   shift4=| v |
##         | oz |          | w |
##         |  1 |          | 1 |
##
## Matica rozsahu sur. osi
## axscale=[xyz ]
##
##
function retval=f_drawCrd3D (origin4, shift4, axscale, figure)

%Label shift const, posunutie oznacenia sur. osi.
lsc=2;

figure=figure;
tx=f_tmtxsh4(shift4);

o10=tx*origin4;
%Suradnice bodov sur.sust. v o1
xp1=[axscale(1);0;0;1]; xm1=[-axscale(1);0;0;1];
yp1=[0;axscale(1);0;1]; ym1=[0;-axscale(1);0;1];
zp1=[0;0;axscale(1);1]; zm1=[0;0;-axscale(1);1];

%suradnice bodov o1 v o0
xp10=tx*xp1;
xm10=tx*xm1;
yp10=tx*yp1;ym10=tx*ym1;
zp10=tx*zp1;zm10=tx*zm1;

o13=f_transfp43(o10)'; % zaciatok posunutej sur sustavy

figure;
% o13 zaciatok posunutej sur sust.o1 voci o0 ale trojriadkova matice pre funkciu drawPoint3d
drawPoint3d(o13,'r','linewidth',4); hold on; % novy zaciatok posunutej sur.sust.
figure;
% nova suradnicova os- os X1
px1=[xp10(1),xm10(1)]; py1=[xp10(2),xm10(2)]; pz1=[xp10(3), xm10(3)];
drawPolyline3d(px1,py1,pz1,'k','linewidth',3,'linestyle',':');hold on;
figure;
drawLabels3d(xp10(1)-lsc, xp10(2)-lsc, xp10(3)-lsc,'x1','fontsize', 20);hold on;

% nova suradnicova os- os Y1
figure;
px2=[yp10(1),ym10(1)]; py2=[yp10(2),ym10(2)]; pz2=[yp10(3), ym10(3)];
drawPolyline3d(px2,py2,pz2,'k','linewidth',3,'linestyle',':');hold on
figure;
drawLabels3d(yp10(1)-lsc, yp10(2)-lsc, yp10(3)-lsc,'y1','fontsize', 20);hold on;

% nova suradnicova os- os Z1
figure;
px3=[zp10(1),zm10(1)]; py3=[zp10(2),zm10(2)]; pz3=[zp10(3), zm10(3)];
drawPolyline3d(px3,py3,pz3,'k','linewidth',3,'linestyle',':');hold on
figure;
drawLabels3d(zp10(1)-lsc, zp10(2)-lsc, zp10(3)-lsc,'z1','fontsize', 20);hold on;

retval=[xp10,xm10,yp10,ym10,zp10,zm10];

endfunction
