%Priklad 1.5.1-20
clc;clearvars;
% Symbolicky vypocet integralu Q
syms x pi c q0  q1

assume(q0,'positive');
assume(c,'positive');

q(x)=q0*sin(x)
q1(x)=x*q0*sin(x)

Iq(x)=int(q,0,pi/2)% integral

xt=double((int(q1,0,pi/2))/(int(q,0,pi/2))) % Vypocet taziska xt
%Zadane hodnoty
a=0.5
b=0.75
c=double(pi/2)
e=0.8
f=0.35
d=1.2
h=0.5
p=0.707

qq0=0.75e3
alf=45
bt=45
gm=46
F1=1200
F2=2500

%Vypocet hodnoty spojiteho bremena
Q = subs(Iq,[q0],[qq0]) % integral funkcie
Qv=double(Q)

A=[0,0,-1;1,1,0;(a+b),0,-d]
AI=inv(A)
b3=-Qv*xt+F2*sind(gm)*c+F2*cosd(gm)*e+F1*sind(bt)*cosd(alf)*(p-f)+F1*sind(bt)*sind(alf)*(p-f)
B=[F1*cosd(bt)+F2*cosd(gm);F1*sind(bt)+Qv-F2*sind(gm);b3]

C=AI*B


