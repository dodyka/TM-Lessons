## Copyright (C) 2024 doc.Ing. Jozef Redl, PhD.
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} b1_click (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: doc.Ing. Jozef Redl, PhD.
## Created: 2024-06-13

function f_b1_click (~,~,htx2,hlb1)
startdir=pwd;
mainpath=uigetdir(startdir);
set(htx2,"string",mainpath,"enable","on","tooltipstring",mainpath);
fls=dir(mainpath);
tmp1=size(fls);
sz=size(fls);
n=0;
tmpa=zeros(1,sz(1));
for j=1:sz(1)
  flag= fls(j).isdir;
  if(flag==0)
     n=n+1;
   endif
endfor
cs=cell(n,1);
k=0;
for i=1:n
     flag= fls(i).isdir;
  if(flag==0)
     s1=fls(i).folder;
     s2=fls(i).name;
     if tmp1(1)!=3
       slsh="\\";
        flp=strcat(s1,slsh,s2);
     else
        flp=strcat(s1,s2);
    endif
     [dr,fnm,fext]=fileparts(flp);
     bret=strcmpi (fext, ".m");
   if bret==1
        k=k+1;
        cs(k,1)=flp;
     endif
endif
endfor
cs = cs(~cellfun('isempty',cs)) ;
global listitems=cell(size(cs));
       listitems=cs;
set(hlb1,'string',cs);
endfunction
