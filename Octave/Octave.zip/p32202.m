% Priklad kmitanie
clc;
pkg load symbolic;

syms y(t)  p q k c m de1 de2  x0 v0

de2=diff(y,t,2)
de1=diff(y,t)
de=de2+p*de1+q*y(t)==0 %Dif rovnica

p=c/m  % tlmic
q=k/m % pruzina

%zaciatocne podmienky
cond1=y(0)==x0
cond2=de1(0)==v0
cond=[cond1 cond2];
%Vypocet dif rovnice
solde=dsolve(de,cond)
solde1=diff(solde,t) % rychlost

%Vypocet s hodnotami
%Rozne varianty hodnot pre nadkriticke, podkriticke a kriticke tlmenie

%Nadkriticke tlmenie
%mm = 5*10^2;kk = 10^3;  cc = 5000;   xx0 = 0.02;  vv0 = 0.05;
%mm = 5*10^3;kk = 10^3;  cc = 5000;   xx0 = 0.02;  vv0 = 0.05;

%Podkriticke tlmenie - tu je kmitanie
%mm = 5*10^3; kk = 50^3;  cc = 5000;  xx0 = 0.02; vv0 = 0.5;
%mm = 5*10^2;kk = 10^4;  cc = 500;   xx0 = 0.02;  vv0 = 0.05;

%kriticke tlmenie
%mm = 5*10^3; kk = 50;   cc = 5000;  xx0 = 0.25; vv0 = 0.005;
%mm = 1000;kk = 4000;  cc = 40000;   xx0 = 0.01;  vv0 = 1;

%%VSTUPNE HODNOTY
%Hodnoty pre zaciatocne podmienky a samotny vypocet
%mm = 5*10^3;     % hmotnost,kg
%kk = 50;       % tuhost pruziny, N/m
%cc = 5000;        % koef.tlmenia, kriticke tlmenie
%xx0 = 0.25;      % zaciatocna poloha, m
%vv0 = 0.005;      % zaciatocna rychlost, m/s
mm = 5*10^2;kk = 10^4;  cc = 500;   xx0 = 0.02;  vv0 = 0.05;

% vypocty:
pint=2*pi
zt = cc/mm;
omn = sqrt(kk/mm)               % vlastna uhlov rychlost kmitania, rad/s
f = omn/(pint)                  % vlastna frekvencia kmitania,Hz
T = 1/f                         % perioda kmita, sec
Zt = cc/(2*mm*omn)              % faktor tlmenia zeta
omd = omn*(sqrt(1-Zt^2))        % prekvencia tlmenia
A = sqrt((xx0^2) + (vv0/omn)^2) % amplituda, m
vm = A*omn                      % maximalna rychlost, m/s
am = vm*omn                     % maximalne zrychlenie, m/s.s
Phi = atand(xx0*omn/vv0)        % fazovy posun, deg
%pp = [1 zt omn^2]
%rts=roots(pp)

pp=cc/mm
qq=kk/mm
tt=pi/4
%Funkcia pre vypocet
fysol=function_handle(solde);


%Vstupne hodnoty pre funkciu
%p, q, t, v0, x0
tt=linspace(0,pint,500);

for i=1:500
ysol(i)=fysol(pp,qq,tt(i),vv0,xx0);

endfor


%Vykreslenie grafu
plot(tt,ysol,'k','LineWidth',1.25);
xlabel('čas, s','fontsize', 12);
%xlabel('čas, s');
ylabel('dráha, m','fontsize', 12);
%ylabel('dráha, m');
title('Tlmene podkriticke kmitanie','fontsize', 14);
set(gca, "fontsize", 16);
hold on;
grid on;
ysolabs=abs(ysol);

 [pks idx] = findpeaks(ysolabs);%najdenie amplitud

sz=size(idx);
delta=(1/sz(2))*log(pks(sz(1))/pks(sz(2))) %log. dekrement

eta=omd/omn % naladenie sustavy
