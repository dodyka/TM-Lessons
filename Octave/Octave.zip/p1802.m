% Priklad Tazisko y= sin(pi*x/L), priklad 1.8-02
clc;
warning('off','all');

pkg load symbolic
syms y x A L c pi S c1
assume([L A c1], 'positive'); % def premenenych ze su kladne

%Definovanie funkcie
y1=A*x*sin(pi*x/L);
y2=A*sin(pi*x/L);
y3=(y2)^2;
disp("Vypocet suradnic taziska funkcie y=A*sin(pi*x/L)");
% Vypocet taziska xt
xt1=int(y1,0,L);
disp("Integral citatel:");
disp(xt1);
xt2=int(y2,0,L);
disp("Integral menovatel:");
disp(xt2);
xt=(xt1/xt2);
disp("Tazisko funkcie , os x, xt=");
disp(xt);

S=xt2;
yt1=int(y3,0,L);
disp("Integral citatel:");
disp(yt1);
disp("Integral menovatel:");
disp(S);

c1=sym(0.5);
yt=c1*yt1/S;
disp("Tazisko funkcie , os y, yt=");
disp(yt);
disp("Koniec vypoctu");

pi=double(pi);
dim=100/pi;
xx=linspace(0,0.01,pi);
A=1;
A=double(A);
L=1;
L=double(L);

xtv=function_handle(xt);
xts=xtv(pi);
%disp(xtv);
ytv=function_handle(yt);
yts=ytv(A);
%disp(ytv);
xx = 0 : 0.01 : pi;
yy =A*sin(xx/L);

f=figure('Name','Tazisko funkcie sin','NumberTitle','off');
hold on;
figure(f);
plot (xx,yy,"black", 'linestyle','-','linewidth',1);
figure(f);
xlabel ("x");
ylabel ("y");
hold on;
figure(f);
plot (xts,yts,"k.", 'linewidth',2,'MarkerSize',8); % cierna bodka

hold on;
figure(f);
set(gca, "linewidth", 1, "fontsize", 8,'fontweight','bold');
figure(f);
title("Ťažisko funkcie y=sin(pi*x/L)")
grid on;
hold on;
figure(f);
%set(gcf,'position',[200,100,800,600]); %funguje
hold off;

