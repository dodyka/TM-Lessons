%Vypocet taziska 1/4kruznice priklad 1.8-03
clc;clearvars;
pkg load symbolic;
disp("Vypocet taziska xt , 1/4 kruznice");
 syms r x y1 y2 xt1 xt2 xt yt1 yt2 yt

assume(r,'positive');
assume(x,'positive');

 y1(x)=x*sqrt(r^2-x^2)
 y2(x)=sqrt(r^2-x^2)
 xt1=int(y1,0,r)
 xt2=int(y2,0,r)
 xt=xt1/xt2

 yt1(x)=(r^2-x^2)/2

 yt2=int(yt1,0,r)

 S=xt2
 yt=yt2/S
