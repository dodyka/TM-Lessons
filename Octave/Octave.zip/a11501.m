##Algoritmus 1.1.5-01
O=[0; 0;0; 1];disp("O=");
disp(O');
r=[3 ;4; 2.5; 1];disp("r=");
disp(r');
O1=f_shfc4(O,r);disp("O1=");
disp(O1');
O13=f_transfp43(O1);disp("O13=");
disp(O13');

