

## Author: dodko283 <dodko283@KKS-190>
## Created: 2024-06-24

%% NIE JE DOKONCENE
function retval = f_drawVector3D (vx, vy, vz,color, vectorname, direction,ctitle,xlbl,ylbl,zlbl)
%digits(4);
vct1=[x0 x1];
vct2=[y0 y1];
vct3=[z0 z1];

f=figure(210200);
set (f,'Name',ctitle,'NumberTitle','off');
set(gcf,'color','w');
set(gca,'FontSize',6);
hold on;
grid on;


plot(vct1,vct2,"Color",color, "LineStyle",'-', "LineWidth", 2);
axis equal;
%text(x1/2+3.5,y1/2+3.5,vectorname);
ht = text ((x1/2)+1.5, (y1/2)+1.5, vectorname, "fontsize", 20);
set (ht, "color", 'black');
%title("Algoritmus 2.1-02");

if direction==1
    text(x1,y1,"+","Color",color,"FontSize",20);
elseif direction==-1
    text(x0,y0,"+","Color",color,"FontSize",20);
elseif direction==0
 %ziadny znak smeru
end
 set(gca, "linewidth", 2, "fontsize", 20)
 xlabel(xlbl);
 ylabel(ylbl);
 %xlabel('Fx, N','FontSize',12,'FontWeight','normal','Color','black');
 %ylabel('Fy, N','FontSize',12,'FontWeight','normal','Color','black');
endfunction
