%Priklad 2.1-01
clc; clearvars;
%pkg load symbolic
syms x t x(t) v0 v1 de1(t) de2(t) C2s C2 % definujem symbolicke premenne
% Zostavenie dif. rovnice
de1=diff(x,t) % prva derivacia
de2=diff(x,t,2) % druha derivacia
de=de2*t-de1+v0 % diferencialna rovnica (1)
%Okrajove podmienky
cond1=x(0)==0
cond2=de1(0)==5
cond=[cond1 cond2];
%Riesenie dif.rovnice
sol=dsolve(de,cond) % riesenie dif. rovnice (1)
%prva derivacia vseobecneho riesenia x(t)'=v(t), aby sme mohli vypocitat integracnu konstantu c2
dfsol=diff(sol,t)==v1
% symbolicky vypocet integracnej konstanty C2, C1=0 na zaklade okrajovych podmienok
C2s=solve(dfsol,C2)
%Vypocet zrychlenia "a", druha derivacia vsobecneho riesenia
df2sol=diff(sol,t,2)
%ciselne premenne pre vypocet
v0=5 % m/s
v1=35 % m/s
t0=0 % s
t1=25 % s
%nove funkcie pre vypocet
vypC2=function_handle(C2s);
C2v=vypC2(t1,v0,v1) % ciselna hodnota C2
%prevod symbolickej funkcie na ciselnu
vypx=function_handle(sol);
% Vypcet ciselnej hodnoty drahy x, v case t1
disp("Draha zrychlenia v case od t0 do t1");
xt=vypx(C2v,t1,v0)
%Ciselny vypocet zrychlenia
sola=function_handle(df2sol);
disp("Zrychlenie a=");
acc=sola(C2v)

