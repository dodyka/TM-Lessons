%Priklad 3.1-03
%Volny pad hm. bodu s odporom vzduchu
clc;
pkg load symbolic;
format short;
syms t g y(t) v0y C1 C2 dey1 dey2 ty qey h ty1 vyt b1
disp('Diferencialna rovnica')
dey1=diff(y,t)
dey2=diff(dey1,t)+b1*dey1-g==0
disp('Riesenie bez podmienok')

soldey0=dsolve(dey2) % riesenie y(t)
soldey1=diff(soldey0,t) % derivacia y(t)'
soldey2=diff(soldey1,t) % druha derivacia y(t)''

disp('Riesenie s podmienkami y(0)=0, dey1(0)=vy(0) v case t0=0')
%Okrajove, zaciatocne podmienky
cond1=y(0)==0
cond2=dey1(0)==v0y
cond=[cond1 cond2];
%Riesenie dif.rovnice
sldy0=(dsolve(dey2,cond)) % -draha
sldy1=diff(sldy0,t) %prva derivacia riesenia - rychlost
sldy2=diff(sldy1,t) % zrychlenie
%Riesenie pre konkretne cisla, parametre tenisovej lopty
disp('Riesenie s cislami'); % pouzijem zdvojenie znacenia z dovodu predchadzajuceho symbolickeho znacenia
vy0=11   % m/s , zaciatocna rychlost
hy=25    % m   , vyska bodu na zemou
%hhy=16 % m   , vyska od zeme kde chcem vediet rychlost , urcujem indexom idx
gg=9.81 % m/s , tiazove zrychlenie
mi=1.81E-7 % viskozita vzduchu, kg*(m*s)^-1
r=0.065 %polomer , m
bb=3*pi*mi*r
mm=0.056 % kg
bb1=bb/mm
dlthy=0.1 % Delta hy - tolerancia na celkovu trajektoriu z dovodu iteracie
% vypocet drahy
fyt=function_handle(sldy0); % vypocet drahy
tt=linspace(0.001,10,1000);
yt=zeros(1,1000);
% cyklus iteracie
for i=1:1000
yt(i)=fyt(bb1,gg,tt(i),vy0);
if(yt(i))>(hy+dlthy) %Ak som uz na zemi prestanem iterovat
idx=round(i/2); %v polovici
disp('Celkova draha, m:');
disp(yt(i-1));
disp('Cas dopadu na zem, s');
disp(tt(i-1));
 break; % prerusenie iteracie, dosiahol som zem
endif
endfor
disp('Udaje pre konkretny cas');
%idx=180;
disp('V case t=, s');
disp(tt(idx));
disp('Rychlost m/s');
fvy=function_handle(sldy1);
vyvyp=fvy(bb1,gg,tt(idx),vy0)
disp('Draha, m');
disp(yt(idx));
disp('Sila odporu vzduchu, N ');
Fd=bb*vyvyp
%Koniec

