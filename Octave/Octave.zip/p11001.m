% Priklad 1.10-01
%Priestorove sustavy telies
%Vstupne parametre
clc; clearvars;
format short;

alf=30
m=30.582
G=m*9.81
A1=[1,0,1,0,0,-cosd(alf)*sind(alf)]
A2=[0,0,0,1,0,-cosd(alf)^2]
A3=[0,1,0,0,1,sind(alf)]
A4=[0,1,0,0,0,sind(alf)]
A5=[0,0,0,0,0,sind(alf)]
A6=[1,0,0,0,0,((cosd(alf)^2)*tand(alf))-sind(alf)*cosd(alf)]
A=[A1;A2;A3;A4;A5;A6]
AI=inv(A)
B=[0;0;G;G/2;G/2;0]
MC=['RAx';'RAz';'ROx';'ROy';'ROz';'S']
C=AI*B


