%Priklad 1.11-03
clc;
pkg load symbolic;
syms  alf fnc alfa a b c
%Goniometricka kvadraticka rovnica
fnc=a*sin(alf)^2-b*sin(alf)+c==0
%Vysledne uhly
alfa=solve(fnc,alf)
%Funkcia pre cisla
alff=function_handle(alfa);
%Vstupne hodnoty

s=1.5
G=981
A=700
ff=0.2
p=1/ff
k=A/(G*s*ff)
aa=p^2+1
bb=2*p*k
cc=k^2-1
F=A/s
%Vypocet
alf12=alff(aa,bb,cc)

a1=alf12(1);
a2=alf12(2);
a3=alf12(3);
a4=alf12(4);

%Kontrola, ktory uhol vyhovuje podla statickych podmienok rovnovahy

Fn3=G*cos(a3)
Ft3=ff*Fn3

Fn4=G*cos(a4)
Ft4=ff*Fn4

SFX3=(A/s)-(G*sin(a3))-Ft3
SFY3=Fn3-G*cos(a3)

SFX4=(A/s)-(G*sin(a4))-Ft4
SFY4=Fn4-G*cos(a4)



