%priklad 1.5.2-02, Obr.1.5.2-05.
clc; clearvars;
pkg load symbolic;

syms Q L phi F phi M1 M2 M2 M3 zr qt ql q

zr=sym(0)
qt=sym(L/3)

ql=L/2
Q=q*L/2

M1=[L/3,0,0]
M2=[0,Q,0]

Mc1=cross(M1,M2)

M3=[2*L,0,0]
M4=[0,F*sin(phi),0] % pre vypocet s realnymi cislami treba uhol phi zadat v radianoch, alebo pouzit funkciu sind a phi v stuponoch


Mc2=cross(M3,M4)
disp("Vysledny moment")
M=Mc1+Mc2
