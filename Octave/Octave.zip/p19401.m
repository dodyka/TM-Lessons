%Príklad 1.9.4-01
clc;
m=95
f=0.2
a=2*pi
S0=9.81*m
S1=S0*e^(f*pi)

