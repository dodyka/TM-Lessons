%Priklad 3.1-02
% Teleso bod hodene smerom dole
clc;
pkg load symbolic;

syms v0y vy(t) y(t) t g m C1 C2 dey1 dey2 ty qey h ty1 vyt b1

dey1=diff(y,t)
dey2=diff(dey1,t)==g;

%Okrajove podmienky
cond1=y(0)==0
cond2=dey1(0)==v0y
cond=[cond1 cond2];
%Riesenie dif.rovnice
soldey2=dsolve(dey2,cond)
soldey1=diff(soldey2,t)

y=soldey2
vy=soldey1

%Riesenie casu t
qey=soldey2-h==0 % prepiseme rovnicu y=..., na tvar (g/2)*t^2+v0y*t-h=0, kde h=y,
%Riesenie kavdratickej rovnice
ty=simplify(solve(qey,t))

ty1=ty(2)

vyt=simplify(subs(vy,t,ty1)) % dosadenie do rovnice za cas t, rychlost v lubovolnej vyske h
%Riesenie pre konkretne cisla
disp('Riesenie s cislami');
vy0=0.1   % m/s , zaciatocna rychlost
hy=25    % m   , vyska bodu na zemou
hhy=16 % m   , vyska od zeme kde chcem vediet rychlost
gg=9.81 % m/s , tiazove zrychlenie
fty=function_handle(ty1); % vypocet casu

disp('Cas dosiahnutia drahy 10m');
thy=fty(gg,hhy,vy0) % cas po prejdeni drahy 10m

disp('Cas dopadu');
th= fty(gg,hy,vy0)  % cas dopadu

disp('Cas dopadu bez zaciatocnej rychlosti');
tvy0=sqrt(2*hy/gg)

disp('Rychlost v bode h=16m');
fvy=function_handle(vy);
vy16m=fvy(gg,thy,vy0)
disp('Rychlost dopadu, h=25m');
vy25m=fvy(gg,th,vy0)



