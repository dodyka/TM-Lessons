%Algoritmus 1.1.5-03
%Rotacia suradnicovej sustavy, pouzitie rozsirenych matic
pkg load matgeom; clc; clearvars;
figure(1);
axd=100;
axi=90;
%Label shift const, posunutie oznacenia sur. osi.
lsc=0;
axis([-axd axd -axd axd -axd axd]);axis equal;grid on;
hold on; view(3); hold on;
set(gca, "linewidth", 2, "fontsize", 14)
xlabel ("x");ylabel ("y");zlabel ("z");
title ("Rotacia sustavy");
figure(1);
%pevna sur.sustava
drawPoint3d(0,0,0,'k','linewidth',5); hold on;
drawLine3d([-axi 0 0   axi 0 0],'linewidth',2);hold on; % os x
drawLabels3d(axi+lsc, 0, 0,'x1','fontsize', 20);hold on;
drawLine3d([0 -axi 0   0 axi 0],'linewidth',2);hold on;
drawLabels3d(0, axi+lsc, 0,'y1','fontsize', 20);hold on;
drawLine3d([0 0 -axi   0 0 40], 'linewidth',2); hold on;% len v smeroch osi vykresluje
drawLabels3d(0, 0, axi+lsc,'z1','fontsize', 20);hold on;

%disp("Ortogonalne suradnice bodu X,Y,Z :"); disp(p1);
%pootocena sus sustava
phi=alpha=beta=gamma=-25;


xp0=[axi;0;0;1]; xm0=[-axi;0;0;1];
yp0=[0;axi;0;1]; ym0=[0;-axi;0;1];
zp0=[0;0;axi;1]; zm0=[0;0;-axi;1];

% transformacna matica rotacie sur systavy
tm=f_rotxyzp4(phi,phi,phi)


% rotovanie suradnice
xp1=tm*xp0; xm1=tm*xm0;
yp1=tm*yp0; ym1=tm*ym0;
zp1=tm*zp0; zm1=tm*zm0;

%Vykreslenie rotovanych suradnic

%Os X s popisom
xr1=[xp1(1) xm1(1) ]; yr1=[xp1(2) xm1(2)]; zr1=[xp1(3) xm1(3)];
drawPolyline3d(xr1,yr1,zr1,'k','linewidth',2,'linestyle',':');hold on;
plx1=[xp1(1)+lsc,xp1(2)+lsc,xp1(3)+lsc];drawLabels3d(plx1,'x2','fontsize', 20);hold on;
%Os Y s popisom
figure(1);
xr2=[yp1(1) ym1(1) ]; yr2=[yp1(2) ym1(2)]; zr2=[yp1(3) ym1(3)];
drawPolyline3d(xr2,yr2,zr2,'k','linewidth',2,'linestyle',':');hold on;
ply1=[yp1(1)+lsc,yp1(2)+lsc,yp1(3)+lsc];drawLabels3d(ply1,'y2','fontsize', 20);hold on;
%Os Z s popisom
figure(1);
xr3=[zp1(1) zm1(1) ]; yr3=[zp1(2) zm1(2)]; zr3=[zp1(3) zm1(3)];
drawPolyline3d(xr3,yr3,zr3,'k','linewidth',2,'linestyle',':');hold on;
plz1=[zp1(1)+lsc,zp1(2)+lsc,zp1(3)+lsc];drawLabels3d(plz1,'z2','fontsize', 20);hold on;



