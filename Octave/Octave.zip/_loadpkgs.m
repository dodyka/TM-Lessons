clc;
disp("Prebieha kontrola potrebných balíčkov...");

[prm1,prm2]=pkg('list');
_sz=size(prm2);
dim=_sz(2);

for i=1:dim
  _tmp=prm2{i}.name;
  _flg=prm2{i}.loaded;
  _flg1=0;
  switch (_tmp)
    case "data-smoothing"
      if _flg==0
        _flg1=1;
        pkg load data-smoothing
        disp("data-smoothing...OK");
      endif
    case "geometry"
      if _flg==0
        _flg1=1;
        pkg load geometry
        disp("geometry...OK");
      endif
    case "matgeom"
      if _flg==0
        _flg1=1;
        pkg load matgeom
        disp("matgeom...OK");
      endif
    case "nurbs"
      if _flg==0
        _flg1=1;
        pkg load nurbs
        disp("nurbs...OK");
      endif
     case "splines"
      if _flg==0
        _flg1=1;
        pkg load splines
        disp("splines...OK");
      endif
      case "symbolic"
      if _flg==0
        _flg1=1;
        pkg load symbolic
        syms _tmp_sym_var;
        clear _tmp_sym_var;
        disp("symbolic...OK");
       endif
       case "mapping"
      if _flg==0
        _flg1=1;
        pkg load mapping
        disp("splines...OK");
      endif
        case "image"
      if _flg==0
        _flg1=1;
        pkg load image
        disp("image...OK");
      endif
        case "quaternion"
      if _flg==0
        _flg1=1;
        pkg load image
        disp("quaternion...OK");
      endif
  endswitch
endfor
if _flg1==1
  disp("Požadované balíčky * boli načítané.");
  btn=questdlg("Chcete zobraziť všetky načítané * a inštalované balíčky ?","Manažér skriptov v.1.0","Yes","No","Cancel","No");
switch (btn)
   case "Yes"
    clc;
    clearvars;
    pkg list;
    case "No";
     disp("Pokracujete..");
    case "Cancel"
      disp("Zrusene");
endswitch
else
   disp("Požadované balíčky * sú už v pamäti.");
   disp("Príkaz: pkg list zobrazí všetky balíčky.");
endif
clearvars;



