%Priklad 2.1-07
clc;clearvars;
syms y(t) t g h v v0 tt hh

de1=diff(y,t)
de2=diff(y,t,2)
de=de2-g==0
%Okrajove, zaciatocne podmienky
cond1=y(0)==0
cond2=de1(0)==v0%
cond=[cond1 cond2];
%Riesenie dif.rovnice
disp("Riesenie dif. rovnice")
disp("Draha")
sol=dsolve(de,cond) % riesenie dif. rovnice (1)
disp("Rychlost")
dsol=diff(sol,t)
disp("Cas dosiahnutia vysky h a rychlosti v")
assume('t','positive');
tt=solve(v==dsol,t)% cas
soll=subs(sol,t,tt);
assume('h','positive');
assume('g','positive');
assume('v0','positive');
assume('v','positive');
disp("Rychlost vo vyske h");
vv=solve(soll==h,v) % rychlost vo vyske h
disp("Vyska h pri rychlosti v");
hh=expand(soll)
