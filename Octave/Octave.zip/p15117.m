%Priklad 1.5.1-17
clc;clearvars;
a=0.2
b=0.3
alf=25
bt=42
gm=8
Ft=895

A=[1,0,-cosd(bt);0,1,sind(bt);0,0,-sind(bt-alf)*a]
AI=inv(A)

B=[-Ft*cosd(gm);Ft*sin(gm);Ft*sind(alf-gm)*(a+b)]

C=AI*B
