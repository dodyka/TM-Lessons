%Algoritmus a1.5-02
clc;clearvars;
%Zadane hodnoty h[m],L[m],M[N.m],F[N],fi[deg]
h=2;L=4; M=1500; F=1850; fi=28;
%Matice-vypocet

A=[0,-1,0;1,0,-1;0,0,L/2];

B=[F*cosd(fi);F*sind(fi);F*cosd(fi)*h/2-F*sind(fi)*L/2-M];

AI=inv(A); C=AI*B;
disp("Matica A");disp(A); disp("Matica B");disp(B);
disp("Inverzna matica AI");disp(AI);
%Reakcie - vysledky
RA=C(1);RB=C(2); RC=C(3); disp("Reakcie RA, RB,RC"); disp(C);
%Suma momentov k bodu B - kontrola vypoctu
disp("Suma momentov k bodu B - kontrola vypoctu=");
SMB=RA*L-RC*L/2+M-F*sind(fi)*L/2-F*cosd(fi)*h/2; disp(SMB);
%Vzdialenost delta
dlt=(M/F)
