%Priklad 3.1-01
clc;
pkg load symbolic;
syms a x(t) y(t) d2y d1t v0 vx0 vy0  t g ymax xmax(t) dex dey x0 y0 t0 C1sx  C1 C2 ley tymax xymax m

v0x=v0*cos(a)
v0y=v0*sin(a)

disp('Diff rovnice v smere X')
dex=diff(x,t)+v0*cos(a) %(1)
%Riesenie dif.rovnice bez okr podm. v smere osi X
soldex=dsolve(dex) % riesenie dif. rovnice (1)
C1sx=solve(soldex,C1)
C1=solve(C1sx,t==0) %stanovime int konst ked bude t=0
x(t)=C1sx
disp('')
disp('Diff rovnice v smere Y')
%Definovanie dif rovnice v smere osi Y
de1y=diff(y,t)
de2y=m*diff(de1y,t)==-g*m
%Okrajove podmienky
cond1=y(0)==0
cond2=de1y(0)==v0y
cond=[cond1 cond2];
solde2y=dsolve(de2y,cond)%riesenie dif rovnice
solde1y=diff(solde2y,t) %prva derivacia riesenia
%Lokalny extrem
ley=diff(solde2y,t)==0 %LoakalnyExtrem y ley
tymax=solve(ley,t)
%Maximalna vyska ymax
ymax=subs(solde2y,t,tymax)
%x-ova suradnica ymax
xymax=simplify(subs(x(t),t,tymax))
x(t)=x(t)
y(t)=solde2y
