%Priklad 3.1-05
clc;
%pkg load symbolic;
%*******************************************************************************
%!!! Z dovodu konvencie riesenia dif. rovnic symbolicky,musime zamenit dx za dy
%*******************************************************************************
syms g va vb t x vx f b L k dydt dydt2 y(t) vA tb vB vBB t12 t1

dydt=diff(y,t)
dydt2=diff(dydt,t)==k*g

%Dif. rovnica
%disp('Riesenie bez podmienok')
%Riesenie dif.rovnice
soldy0=dsolve(dydt2) % -draha
soldy1=diff(soldy0,t) %prva derivacia riesenia - rychlost

%disp('Riesenie s podmienkami y(0)=0, dey1(0)=vy(0) v case t0=0')
%Okrajove, zaciatocne podmienky
cond1=y(0)==0
cond2=dydt(0)==vA
cond=[cond1 cond2];
%Riesenie dif.rovnice
sldy0=(dsolve(dydt2,cond)) % -draha
sldy1=diff(sldy0,t) %prva derivacia riesenia - rychlost
%sldy2=diff(sldy1,t) % zrychlenie
k=g*(sin(b)-f*cos(b))
%Rychlost vB
vBB=sldy1-vB==0
%vyjadrenie casu
tb=solve(vBB,t)
%Vypocet casu , nie v bode B, ale vseobecne
t12=solve(sldy0-L==0,t)
t1=t12(2)

%Rychlost v bode B
vB=simplify(subs(sldy1,t,t1))
