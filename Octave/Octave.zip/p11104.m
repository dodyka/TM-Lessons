%Priklad 1.11-04
clc; clearvars;
syms ml l a F g x F(x) f
disp("Rovnica na integraciu");
F(x)=(ml*g/l)*(f*cos(a)+sin(a))*x
disp("Integral funkcie F(x)");
IFx=int(F(x),0,l)
disp("Rovnicu upravime");
sIFx=simplify(IFx)

Avyp=function_handle(sIFx);

%Vypocet
disp("Vypocet");
% Zadane udaje
aa=25*(pi/180) % hodnata v radianoch
ll=2.3
m1m=3.29 % hmotnost jedneho (1) metra
mL=m1m*ll % hmotnost celeho lana
ff=0.3
%Praca A
disp("Praca A[N.m] sily F");
A=Avyp(aa,ff, 9.81, ll, mL)

