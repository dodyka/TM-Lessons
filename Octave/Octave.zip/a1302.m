%Algoritmus a1.3-02
clc;clear vars;
warning off;
F1=quaternion(0,-30,50,-70)
F2=quaternion(0,90,-40,20)
F3=quaternion(0,-20,-120,30)
SF=[F1,F2,F3];% sustava vektorov
disp("Suma vektorov: FV :");
FV=sum(SF); FV
disp("Dlzka vektora FV :");
FVL=norm(FV);
disp(FVL);
disp("Smerove kosiny k osiam x,y,z");
[axs,angl]=q2rot(FV)
disp("Uhly vektora voci osiam x,y,z =");
acosd(axs)
disp("Smerovy vektor e0:");
e0=quaternion(0,axs(1,1),axs(2,1),axs(3,1))

Fx=get(FV,"x");Fy=get(FV,"y");Fz=get(FV,"z");


%warning on;

