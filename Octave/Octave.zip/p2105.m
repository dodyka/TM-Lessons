%Priklad 2.1-05
clc;clearvars;
pkg load symbolic;
syms a om t fi(t) acc % a-alfa om -omega

% Zostavenie dif. rovnice
de1=diff(fi,t) % prva derivacia
de2=diff(fi,t,2) % druha derivacia
de=de2==a % diferencialna rovnica (1)
%Okrajove podmienky
cond1=fi(0)==0
cond2=de1(0)==0 %
cond=[cond1 cond2];
%Riesenie dif.rovnice
disp("Uhol fi")
sol=dsolve(de,cond) % riesenie dif. rovnice (1)
disp("Uhlova rychlost omega")
dsol=diff(sol,t) %prva derivacia vseobecneho riesenie
%Vypocet
fiv=function_handle(sol);
omv=function_handle(dsol);
%Vstupne hodnoty
fih=2*pi
tt1=12
tt2=18
r=1
alfa=2*fih/tt1^2
omega=omv(alfa,tt2)
an=r*omega^2
at=alfa*r
a=sqrt(an^2+at^2)
