%Priklad 3.4.1-01
clc;
pkg load symbolic;

syms LG m RTy JT a21 M2 G JA L
A=[1,m*LG;LG, -JT]
AI=inv(A)
B=[G;-M2]
C=[RTy;a21]

C=simplify(AI*B)
%Variant B
%JA=(sym(1/3))*m*(L)^2
eqB=M2+G*LG-JA*a21==0

solB=solve(eqB,a21)

%Dosadime cisla
LL=2 %m
LGG=LL/2 %m
mm=30 %kg
om=3 %rad/s
MM2=80 % N.m
GG=mm*9.81
JTT=(1/12)*(mm*(LL^2))
JAA=(1/3)*(mm*(LL^2))

solRnx=mm*om^2*LGG

fRTy=function_handle(C(1))
solRTy=fRTy(GG,JTT,LGG,MM2,mm)

fa21=function_handle(C(2))
sola21=fa21(GG,JTT,LGG,MM2,mm)


disp("Variant B vypoctu a21")
fa21b=function_handle(solB)
sola21b=fa21b(GG,JAA,LGG,MM2)
disp("");
disp("Vysledky vypoctu");
disp("");
disp("Reakcia RnAx= ,[N]");
disp(solRnx);
disp("Reakcia RtAy= ,[N]");
disp(solRTy);
disp("Uhlove zrychlenie om21= , [rad/s^2]");
disp(sola21);




