%Priklad 1.9.1-01

m=500
h=0.4
L=0.5
alf=30
g=9.81
f=0.2
G=m*g
F=G*((cosd(alf)*f+sind(alf))/(cosd(alf)-sind(alf)))
dx=(F*sind(alf)*L/2+F*cosd(alf)*h/2-G*sind(alf)*h/2)/(F*sind(alf)+G*cosd(alf))

