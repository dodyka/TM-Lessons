%Priklad Tu treba zmenit cislovanie
%Toto je dynamika sustavy hmotnych bodov
clc;
pkg load symbolic;
syms ac aa F Gb Ga alf ma mb r1 r2 r3

r1=2*ac+aa==0
r2=-mb*ac-Gb*sin(alf)+2*F==0
r3=-ma*aa-Ga+F==0
res=solve(r1,r2,r3, "ac","aa","F");

aC=res.ac
aA=res.aa
Fv=res.F

%Zadane hodnoty
ya=1
g=9.81
maa=150
mbb=45
GBB=mbb*g
GAA=maa*g
alfa=30

fac=function_handle(aC);
faa=function_handle(aA);
fFv=function_handle(Fv);
%Vysledky
acv=fac(GAA,GBB,alfa,maa,mbb)
aav=faa(GAA,GBB,alfa,maa,mbb)
Fvv=fFv(GAA,GBB,alfa,maa,mbb)
va=sqrt(2*abs(aav)*ya)
