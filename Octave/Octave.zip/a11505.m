%Algoritmus 1.1.5-05
%Vykreslenie pootoceneho bodu A1 o uhol alpha=-21deg, beta=-31deg, gamma=-41deg
      pkg load matgeom;clearvars; clc;
      %Bod A,  rozsah sur.osi.
      A1=[-2 4 3];alpha=-21;beta=-31;gamma=-41;
      rto=1;axs1=-10; axs2=10;  axs3=10;stp=3; %konstantne parametre
      disp("A1");disp(A1);
      figure(11505); clf;
     % axd=10;
      %axis([-axd axd -axd axd -axd axd]);axis equal;grid on;
      drawPoint3d(A1,'k','linewidth',10); hold on;
      lba=[A1(1) A1(2)+rto A1(3)+rto];drawLabels3d(lba,'A1','fontsize', 20);hold on;
      %Transformacna matica 3x3
      Tx=rotx(alpha); Ty=roty(beta);Tz=rotz(gamma);
      Tm=Tx*Ty*Tz;
      disp("Tm");disp(Tm);
      A1r=A1*Tm; %Pootocene suradnice bodu A-> pootoceny bod A1
      disp("A1r");disp(A1r);
     %Transformacna matica 4x4 (pouzitie rozsirenej matice)
      A14=f_transfp34(A1); %Rozsirena matica 4x1
      Tm4=f_rotxyzp4(alpha,beta,gamma);
      disp("Tm4");disp(Tm4);
      A14r=(Tm4')*(A14') % Matice musia but transponovane
      drawPoint3d(A1r,'r','linewidth',15); hold on;% vykreslenie bodu A1r - ok
      lba1=[A1r(1) A1r(2)+rto A1r(3)+rto];drawLabels3d(lba1,'A1r','fontsize', 20);hold on;
      origin4=[0;0;0;1];shift4=[0;0;0;1];axscale=10; fig=figure(11505);% vykreslenie osi x y z
      ret=f_drawCrd3D (origin4, shift4, axscale, fig);
      Ax=[0 A1(1)]; Ay=[0 A1(2)]; Az=[0 A1(3)];
      drawPolyline3d(Ax,Ay,Az,'k','linewidth',2,'linestyle',':');
      Ax1=[0 A1r(1)]; Ay1=[0 A1r(2)]; Az1=[0 A1r(3)];
      drawPolyline3d(Ax1,Ay1,Az1,'k','linewidth',2,'linestyle','--');
      set(gca, "linewidth", 2, "fontsize", 14);
      axis([axs1  axs2 axs1 axs2 axs1 axs2]); % definovanie rozsahu sur. osi
      set(gca,'XTick',[axs1:stp:axs2]);set(gca,'YTick',[axs1:stp:axs2]); % hustota mriezky
      set(gca,'ZTick',[axs1:stp:axs2]);
      xlabel ("x");ylabel ("y");zlabel ("z"); grid on;axis equal;
      title ("Rotácia bodu okolo osí x1,y1,z1 ");
      view(3);
