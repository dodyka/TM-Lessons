##Algoritmus 1.1.4-01

pkg load matgeom;clearvars; clc;
figure(11401); clf;hold on;
axis([-10 10 -10 10 -10 10]);hold on;
cc=[0 0 0 ];r=8;theta=65; phi=15;
drawCircle3d([cc r  theta  phi], 'LineWidth', 4, 'Color', 'k');
view(3); hold on;
set(gca, "linewidth", 2, "fontsize", 14)
xlabel ("x");ylabel ("y");zlabel ("z");
hold on; grid on;axis equal;
title ("3D Kružnica v polárnych súradniciach ");  ;
str0=strcat('r = ', num2str(r));
str1=strcat('\theta = ', num2str(theta));
str2=strcat('\phi = ', num2str(phi));
drawLabels3d(2,-10,10,str0,'fontsize', 20);hold on;
drawLabels3d(2,-10,7,str1,'fontsize', 20);hold on;
drawLabels3d(2,-10,4,str2,'fontsize', 20);hold on;

