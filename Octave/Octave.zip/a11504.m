%Algoritmus 1.1.5-04
%Vykreslenie pootoceneho bodu A o uhol -21deg
      pkg load matgeom;clearvars; clc;
      A1=[0 4 3];alpha=-21;
      rto=0.25;axs1=0; axs2=5; stp=1; %konstantne parametre
      disp("A1");disp(A1);
      figure(1); clf;
      drawPoint3d(A1,'k','linewidth',10); hold on;
      lba=[A1(1) A1(2)+rto A1(3)+rto];drawLabels3d(lba,'A1','fontsize', 20);hold on;
      Tx=rotx(alpha); %Transformacna matica
      disp("Tx");disp(Tx);
      A1r=A1*Tx; %Pootocene suradnice bodu A1-> pootoceny bod A1r
      disp("A1r");disp(A1r);
      drawPoint3d(A1r,'k','linewidth',15); hold on;% vykreslenie bodu A1
      lba1=[A1r(1) A1r(2)+rto A1r(3)+rto];drawLabels3d(lba1,'A1r','fontsize', 20);hold on;
      Ax=[0 A1(1)]; Ay=[0 A1(2)]; Az=[0 A1(3)];
      drawPolyline3d(Ax,Ay,Az,'k','linewidth',2,'linestyle',':');
      Ax1=[0 A1r(1)]; Ay1=[0 A1r(2)]; Az1=[0 A1r(3)];
      drawPolyline3d(Ax1,Ay1,Az1,'k','linewidth',2,'linestyle','--');
      set(gca, "linewidth", 2, "fontsize", 14);
      axis([axs1  axs2 axs1 axs2 axs1 axs2]);
      set(gca,'XTick',[axs1:stp:axs2]);set(gca,'YTick',[axs1:stp:axs2]);
      set(gca,'ZTick',[axs1:stp:axs2]);
      xlabel ("x");ylabel ("y");zlabel ("z"); grid on;axis equal;
      title ("Rotacia bodu okolo osi x ");
      view(3);

