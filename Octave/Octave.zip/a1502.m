%Algoritmus a1.5-03
clc;clearvars;
q=195
L=2.8
Q=q*L


A=[1,0,0;0,0,L;0,L,0]
B=[0;Q*L/2;Q*L/2]
AI=inv(A)
C=AI*B

