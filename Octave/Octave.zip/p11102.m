% Priklad 1.11-02
clc;clearvars;
%Vsupne hodnoty
%Moje hodnoty
G=14.322
Q=1962
rp=5E-3
r1=48E-3
f=0.08
h=2.5
%Riesenie
A=[1,-1;-f*(rp/r1),1]
AI=inv(A)
B=[G+Q/2;Q/2]
C=AI*B
R1=C(1)
F=C(2)
A=F*h





