## Copyright (C) 2024 dodko283
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <https://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {} {@var{retval} =} _initmsg (@var{input1}, @var{input2})
##
## @seealso{}
## @end deftypefn

## Author: dodko283 <dodko283@KKS-190>
## Created: 2024-06-14

function f_initmsg ()
msg1="Vitajte ! \n \n";
msg2="Spustili ste jednoduchú aplikáciu napísanú v GNU Octave. \n";
msg3="GNU Octave je voľne šíriteľný softvér, ktorý nie je dokonalý a má veľa chýb. \n";
msg4="Preto s ním majte trpezlivosť. Na naše výpočty však postačuje. \n";
msg5="Niekedy je nutné program ukončiť a znova spustiť aby sa skript spustil (ver.9.1.0). \n";
msg6="Aj napriek týmto nedostatkom, nám dáva dobre napísaný algoritmus elegantné výsledky. \n";
msg7="Dúfam, že Vám tieto algoritmy pomôžu lepšie pochopiť prednášané učivo. \n";
msg8="Prajem Vám veľa úspechov.\n \n";
msg9="Autor (jozef.redl@uniag.sk)";

msg=strcat(msg1, msg2 ,msg3, msg4, msg5, msg6, msg7, msg8, msg9);

myicon = imread("info.jpg");
h = msgbox(msg,"Manažér skriptov v.1.0.","custom",myicon, "modal");

endfunction
